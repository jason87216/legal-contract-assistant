# 成熟契約模板與官方參考來源

本清單只列來源與用途，不重製官方模板全文。實作時請到來源逐條核對並記錄版本日期。

## portal｜行政院全球資訊網：定型化契約範本
- 用途：成熟官方模板入口，可用來找買賣、租賃、車輛、電器等範本。
- URL：https://www.ey.gov.tw/Page/37D1D3EDDE2438F8

## portal｜行政院全球資訊網：定型化契約應記載及不得記載事項
- 用途：比範本更適合轉成審查規則；可作為缺漏條款與不得記載條款的來源。
- URL：https://www.ey.gov.tw/Page/2285E9A14973DE75

## lease｜住宅租賃契約書範本
- 用途：住宅租賃主模板，適合用來建立租賃合約標準欄位與條款順序。
- URL：https://www.ey.gov.tw/Page/AABD2F12D8A6D561/58973c69-07f0-4b88-88a2-8b0b91f28241

## lease｜住宅租賃定型化契約應記載及不得記載事項
- 用途：租賃審查規則核心來源，特別適合轉成 required / prohibited checklist。
- URL：https://www.ey.gov.tw/Page/DFB720D019CCCB0A/478917df-7599-418f-8715-fd2716b623b4

## lease｜內政部不動產資訊平台：契約書範本
- 用途：可參考住宅租賃、轉租、委託管理等不動產相關契約。
- URL：https://pip.moi.gov.tw/Publicize/Info/G1020

## sale｜成屋買賣契約書範本
- 用途：買賣契約中最完整的成熟官方模板之一，條款結構完整。
- URL：https://www.ey.gov.tw/Page/AABD2F12D8A6D561/217c24e2-cacd-44ca-8d6f-0db109b3f45b

## sale｜成屋買賣定型化契約應記載及不得記載事項
- 用途：可作為買賣合約審查規則來源，尤其是標的、價款、現況確認、違約等。
- URL：https://www.ey.gov.tw/Page/DFB720D019CCCB0A/866026ec-3719-4a41-898c-cda58b1b32d9

## sale｜預售屋買賣契約書範本
- 用途：買賣合約進階參考，適合學交付、驗收、保固、履約擔保等條款設計。
- URL：https://www.ey.gov.tw/Page/AABD2F12D8A6D561/74c471a9-6a76-4f71-bbda-8e59de030048

## sale｜預售屋買賣定型化契約應記載及不得記載事項
- 用途：可擴充買賣類審查規則，尤其是審閱期、總價、驗收、保固。
- URL：https://www.ey.gov.tw/Page/DFB720D019CCCB0A/7beaa539-d140-4e03-97c3-020b68a9692c

## sale｜汽車買賣定型化契約範本
- 用途：一般商品買賣之外的成熟車輛買賣模板，可參考規格、交車、保固、付款。
- URL：https://www.ey.gov.tw/Page/AABD2F12D8A6D561/3edfaf30-4467-48b6-9005-6dac8f429028

## sale｜中古汽車買賣定型化契約範本
- 用途：二手標的買賣測試很適合，特別是現況、里程、瑕疵揭露、保固。
- URL：https://www.ey.gov.tw/Page/AABD2F12D8A6D561/60ad4097-ba3a-40b5-aad5-24a446c62437

## sale｜電器買賣定型化契約範本
- 用途：一般民生日常商品買賣參考模板，可測驗保固、安裝、交付、退換。
- URL：https://www.ey.gov.tw/Page/AABD2F12D8A6D561/30964882-e2ac-4cc1-b221-f2272cc6ce61

## labor｜勞動部：勞動契約主題頁
- 用途：不是單一通用模板，但有定期契約、試用期、調動、最低服務年限、競業禁止等重要審查題材。
- URL：https://www.mol.gov.tw/1607/28162/28296/28340/nodelist

## labor｜勞動部：部分時間工作勞工勞動契約參考範本
- 用途：官方參考範本，適合建立部分工時測試案例。
- URL：https://www.mol.gov.tw/topic/9677/27016/

## labor｜勞動部：勞動派遣期間勞動契約書範本
- 用途：官方派遣契約範本，可用來擴充特殊勞動契約類型。
- URL：https://www.mol.gov.tw/1607/28162/28296/28340/28364/28374/lpsimplelist

## labor｜臺北市政府勞動局：如何訂定優質勞動契約
- 用途：地方主管機關提供的勞動契約訂定說明，適合補足一般勞動契約欄位。
- URL：https://bola.gov.taipei/ct.asp?ctNode=62846&mp=116003&xItem=65303301

## labor｜彰化縣政府：勞動契約範本
- 用途：地方政府提供一般勞動契約與勞動部部分工時契約範本下載。
- URL：https://labor.chcg.gov.tw/06service/service01_con.aspx?data_id=20630&topsn=4826

## labor｜行政院人事行政總處：約用人員勞動契約範本
- 用途：公部門約用人員契約參考，可測試期間、工作內容、報酬、終止等條款。
- URL：https://www.dgpa.gov.tw/mp/info?mid=152&pid=11851&uid=202

## labor｜勞動部：工作規則參考手冊
- 用途：不是合約模板，但很多勞動契約條款會引用工作規則，適合後續擴充審查項。
- URL：https://www.mol.gov.tw/1607/28162/28166/28236/28238/lpsimplelist

