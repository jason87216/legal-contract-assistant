# 台灣合約審查機器人測試資料包 v1

## 內容

- `contracts/sale/`：買賣合約合成測試樣本 30 份
- `contracts/labor/`：勞動合約合成測試樣本 30 份
- `contracts/lease/`：租賃合約合成測試樣本 30 份
- `manifest.csv`：測試樣本索引與預期風險主題
- `manifest.json`：同上，供程式讀取
- `sources/official_template_sources.md`：成熟/官方模板來源清單
- `sources/official_template_sources.csv`：同上，供匯入資料庫

## 使用建議

這些合約是「合成測試資料」，不是正式法律文件，也不是官方範本。
用途是測試你的 CLI 報告流程，例如：

1. contract classifier 是否判斷出買賣/勞動/租賃
2. clause extractor 是否能切出價金、期限、修繕、加班、保固等條款
3. law retrieval 是否能依合約類型與風險主題查到法條
4. report writer 是否能輸出高中低風險與人工複核提醒

## 第一階段建議評測指標

- `contract_type_accuracy`：合約類型判斷正確率
- `risk_level_accuracy`：高/中/低風險粗分類正確率
- `risk_theme_recall`：manifest 中的 expected_risk_themes 是否被提及
- `citation_presence`：報告是否有引用法條/來源
- `manual_review_flag`：資料不足時是否標示人工複核，而不是胡亂斷言

## 重要提醒

- 官方模板全文請從來源下載並逐條核對，不要直接依本資料包推定法律正確性。
- 若要把官方模板放入資料庫，建議只存必要欄位、來源 URL、版本日期、條款標題與你自己整理的審查標籤。
- 不建議直接把官方 PDF 全文重製進公開 repo，除非你確認授權與合理使用範圍。
